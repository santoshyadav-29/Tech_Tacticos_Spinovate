'use client';

import React, { useState } from 'react';
import { Filter, ExternalLink, Calendar, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const Research = () => {
  const [activeFilter, setActiveFilter] = useState('All');

  const categories = ['All', 'Electrolysis', 'Fuel Cells', 'Storage', 'Policy', 'Materials'];

  const projects = [
    {
      title: 'Advanced PEM Electrolysis Systems',
      category: 'Electrolysis',
      description: 'Developing next-generation proton exchange membrane electrolyzers with improved efficiency and reduced costs.',
      image: 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg?auto=compress&cs=tinysrgb&w=600',
      tags: ['PEM', 'Efficiency', 'Cost Reduction'],
      collaborators: ['MIT', 'Stanford'],
      date: '2023-2025',
      status: 'Active'
    },
    {
      title: 'Solid-State Hydrogen Storage',
      category: 'Storage',
      description: 'Research into metal hydride materials for safe and efficient hydrogen storage solutions.',
      image: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=600',
      tags: ['Metal Hydrides', 'Safety', 'Storage'],
      collaborators: ['CalTech', 'Toyota'],
      date: '2024-2026',
      status: 'Active'
    },
    {
      title: 'Hydrogen Policy Framework',
      category: 'Policy',
      description: 'Developing comprehensive policy recommendations for hydrogen economy implementation.',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=600',
      tags: ['Policy', 'Economics', 'Implementation'],
      collaborators: ['DOE', 'EU Commission'],
      date: '2023-2024',
      status: 'Completed'
    },
    {
      title: 'High-Temperature Fuel Cells',
      category: 'Fuel Cells',
      description: 'Advancing solid oxide fuel cell technology for industrial applications.',
      image: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=600',
      tags: ['SOFC', 'High Temperature', 'Industrial'],
      collaborators: ['GE', 'Siemens'],
      date: '2024-2027',
      status: 'Active'
    },
    {
      title: 'Nanostructured Catalysts',
      category: 'Materials',
      description: 'Engineering advanced catalytic materials for improved hydrogen production efficiency.',
      image: 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg?auto=compress&cs=tinysrgb&w=600',
      tags: ['Catalysts', 'Nanomaterials', 'Efficiency'],
      collaborators: ['NREL', 'Berkeley'],
      date: '2023-2025',
      status: 'Active'
    },
    {
      title: 'Green Ammonia Production',
      category: 'Electrolysis',
      description: 'Developing processes for sustainable ammonia synthesis using green hydrogen.',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=600',
      tags: ['Ammonia', 'Synthesis', 'Sustainability'],
      collaborators: ['Yara', 'BASF'],
      date: '2024-2026',
      status: 'Active'
    }
  ];

  const filteredProjects = activeFilter === 'All' 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  const publications = [
    {
      title: 'Breakthrough in Low-Cost Electrocatalysts for Water Splitting',
      journal: 'Nature Energy',
      date: '2024',
      impact: 'High Impact'
    },
    {
      title: 'Solid-State Hydrogen Storage: Materials and Applications',
      journal: 'Science',
      date: '2024',
      impact: 'High Impact'
    },
    {
      title: 'Economic Analysis of Green Hydrogen Production Pathways',
      journal: 'Energy Policy',
      date: '2023',
      impact: 'Medium Impact'
    },
    {
      title: 'Advanced Fuel Cell Technologies for Transportation',
      journal: 'Journal of Power Sources',
      date: '2023',
      impact: 'Medium Impact'
    }
  ];

  return (
    <section id="research" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16 scroll-reveal">
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk mb-6 bg-gradient-to-r from-gray-900 to-blue-800 bg-clip-text text-transparent">
            Research & Innovation
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Pioneering breakthrough research across the hydrogen value chain, from production to storage and utilization.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-2 mb-12 scroll-reveal">
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeFilter === category ? "default" : "outline"}
              onClick={() => setActiveFilter(category)}
              className={`${
                activeFilter === category 
                  ? 'bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700' 
                  : 'hover:border-primary hover:text-primary'
              } transition-all duration-200`}
            >
              <Filter className="w-4 h-4 mr-2" />
              {category}
            </Button>
          ))}
        </div>

        {/* Research Projects */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {filteredProjects.map((project, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group scroll-reveal">
              <div className="relative overflow-hidden rounded-t-lg">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4">
                  <Badge variant={project.status === 'Active' ? 'default' : 'secondary'}>
                    {project.status}
                  </Badge>
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-xl font-space-grotesk group-hover:text-primary transition-colors">
                  {project.title}
                </CardTitle>
                <Badge variant="outline" className="w-fit">
                  {project.category}
                </Badge>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4 leading-relaxed">{project.description}</p>
                
                <div className="flex flex-wrap gap-1 mb-4">
                  {project.tags.map((tag, tagIndex) => (
                    <Badge key={tagIndex} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="space-y-2 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    {project.date}
                  </div>
                  <div className="flex items-center">
                    <Users className="w-4 h-4 mr-2" />
                    {project.collaborators.join(', ')}
                  </div>
                </div>

                <Button variant="outline" className="w-full mt-4 group-hover:border-primary group-hover:text-primary">
                  Learn More
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Publications */}
        <div className="scroll-reveal">
          <h3 className="text-3xl font-bold font-space-grotesk text-center mb-12">Recent Publications</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {publications.map((pub, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <Badge variant={pub.impact === 'High Impact' ? 'default' : 'secondary'}>
                      {pub.impact}
                    </Badge>
                    <span className="text-sm text-gray-500">{pub.date}</span>
                  </div>
                  <h4 className="text-lg font-semibold mb-2 font-space-grotesk">{pub.title}</h4>
                  <p className="text-green-600 font-medium">{pub.journal}</p>
                  <Button variant="ghost" className="p-0 h-auto mt-2 text-blue-600 hover:text-blue-700">
                    View Publication
                    <ExternalLink className="w-4 h-4 ml-1" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Research;