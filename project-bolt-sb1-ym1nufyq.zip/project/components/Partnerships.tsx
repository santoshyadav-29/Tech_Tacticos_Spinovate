'use client';

import React from 'react';
import { Building2, Handshake, Award, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Partnerships = () => {
  const partners = [
    {
      name: 'MIT Energy Initiative',
      type: 'Academic',
      logo: 'https://images.pexels.com/photos/256381/pexels-photo-256381.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Joint research on advanced electrolysis technologies'
    },
    {
      name: 'Toyota Motor Corp',
      type: 'Industry',
      logo: 'https://images.pexels.com/photos/256381/pexels-photo-256381.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Fuel cell vehicle technology development'
    },
    {
      name: 'Department of Energy',
      type: 'Government',
      logo: 'https://images.pexels.com/photos/256381/pexels-photo-256381.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'National hydrogen strategy implementation'
    },
    {
      name: 'Shell New Energies',
      type: 'Industry',
      logo: 'https://images.pexels.com/photos/256381/pexels-photo-256381.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Large-scale hydrogen production projects'
    },
    {
      name: 'Stanford University',
      type: 'Academic',
      logo: 'https://images.pexels.com/photos/256381/pexels-photo-256381.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Materials science research collaboration'
    },
    {
      name: 'Siemens Energy',
      type: 'Industry',
      logo: 'https://images.pexels.com/photos/256381/pexels-photo-256381.jpeg?auto=compress&cs=tinysrgb&w=200',
      description: 'Industrial hydrogen applications'
    }
  ];

  const opportunities = [
    {
      icon: <Building2 className="w-8 h-8" />,
      title: 'Industry Partnerships',
      description: 'Collaborate on commercial hydrogen technology development and deployment',
      benefits: ['Technology transfer', 'Joint R&D projects', 'Pilot programs', 'Market insights']
    },
    {
      icon: <Handshake className="w-8 h-8" />,
      title: 'Academic Collaboration',
      description: 'Partner with leading universities on fundamental research and education',
      benefits: ['Student exchange', 'Joint publications', 'Shared facilities', 'Knowledge transfer']
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Grant Partnerships',
      description: 'Join forces on major funding opportunities and research initiatives',
      benefits: ['Larger project scope', 'Shared resources', 'Risk mitigation', 'Broader impact']
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: 'Strategic Alliances',
      description: 'Long-term partnerships aligned with hydrogen economy development',
      benefits: ['Market development', 'Policy influence', 'Standard setting', 'Global reach']
    }
  ];

  return (
    <section id="partnerships" className="py-20 bg-gradient-to-br from-blue-50 to-green-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16 scroll-reveal">
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk mb-6 bg-gradient-to-r from-gray-900 to-blue-800 bg-clip-text text-transparent">
            Partnerships & Collaboration
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Building strategic alliances across academia, industry, and government to accelerate hydrogen innovation and deployment.
          </p>
        </div>

        {/* Current Partners */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold font-space-grotesk text-center mb-12 scroll-reveal">Our Partners</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {partners.map((partner, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group scroll-reveal">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto mb-4 overflow-hidden group-hover:scale-105 transition-transform duration-300">
                    <img
                      src={partner.logo}
                      alt={partner.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h4 className="text-lg font-semibold mb-2 font-space-grotesk">{partner.name}</h4>
                  <div className="inline-block px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full mb-3">
                    {partner.type}
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">{partner.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Partnership Opportunities */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold font-space-grotesk text-center mb-12 scroll-reveal">Partnership Opportunities</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {opportunities.map((opportunity, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 scroll-reveal">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-blue-100 rounded-full flex items-center justify-center mb-4">
                    <div className="text-green-600">{opportunity.icon}</div>
                  </div>
                  <CardTitle className="text-xl font-space-grotesk">{opportunity.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4 leading-relaxed">{opportunity.description}</p>
                  <div className="space-y-2">
                    <h5 className="font-semibold text-sm text-gray-800">Key Benefits:</h5>
                    <ul className="space-y-1">
                      {opportunity.benefits.map((benefit, benefitIndex) => (
                        <li key={benefitIndex} className="text-sm text-gray-600 flex items-center">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2"></div>
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center scroll-reveal">
          <Card className="border-0 shadow-xl bg-gradient-to-r from-green-500 to-blue-600 text-white max-w-4xl mx-auto">
            <CardContent className="p-12">
              <h3 className="text-3xl font-bold font-space-grotesk mb-6">Ready to Partner With Us?</h3>
              <p className="text-xl mb-8 opacity-90 leading-relaxed">
                Join our mission to accelerate the hydrogen economy through collaborative innovation. 
                Let's create breakthrough solutions together.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" variant="secondary" className="bg-white text-gray-900 hover:bg-gray-100 px-8 py-3">
                  Partnership Inquiry
                </Button>
                <Button size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-gray-900 px-8 py-3">
                  Download Partnership Guide
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Partnerships;