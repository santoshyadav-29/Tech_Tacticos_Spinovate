'use client';

import React, { useEffect, useRef } from 'react';
import { ArrowRight, Play, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = document.querySelectorAll('.scroll-reveal');
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 gradient-green-blue animate-gradient opacity-10"></div>
      
      {/* Animated background particles */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-2 h-2 bg-green-400 rounded-full animate-ping opacity-20"></div>
        <div className="absolute top-40 right-32 w-3 h-3 bg-blue-400 rounded-full animate-pulse opacity-30"></div>
        <div className="absolute bottom-32 left-1/4 w-2 h-2 bg-emerald-400 rounded-full animate-bounce opacity-25"></div>
        <div className="absolute top-1/3 right-20 w-1 h-1 bg-cyan-400 rounded-full animate-ping opacity-20"></div>
      </div>

      <div ref={heroRef} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="scroll-reveal">
          <h1 className="text-5xl md:text-7xl font-bold font-space-grotesk mb-6 bg-gradient-to-r from-gray-900 via-green-800 to-blue-800 bg-clip-text text-transparent leading-tight">
            Pioneering the Future of
            <span className="block bg-gradient-to-r from-green-500 to-blue-600 bg-clip-text text-transparent">
              Green Hydrogen
            </span>
          </h1>
        </div>

        <div className="scroll-reveal">
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto leading-relaxed">
            Leading breakthrough research in sustainable hydrogen technology, driving innovation 
            for a carbon-neutral future through cutting-edge science and global collaboration.
          </p>
        </div>

        <div className="scroll-reveal flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Button size="lg" className="bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white px-8 py-3 text-lg group">
            Explore Our Research
            <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button size="lg" variant="outline" className="border-2 border-gray-300 hover:border-primary text-gray-700 px-8 py-3 text-lg group">
            <Play className="mr-2 h-5 w-5 group-hover:scale-110 transition-transform" />
            Watch Our Story
          </Button>
        </div>

        {/* Stats */}
        <div className="scroll-reveal grid grid-cols-1 md:grid-cols-4 gap-8 mt-16">
          {[
            { value: '50+', label: 'Research Projects' },
            { value: '200+', label: 'Publications' },
            { value: '25+', label: 'Global Partners' },
            { value: '15+', label: 'Patents Filed' },
          ].map((stat, index) => (
            <div key={index} className="text-center group">
              <div className="text-4xl md:text-5xl font-bold font-space-grotesk bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-300">
                {stat.value}
              </div>
              <div className="text-gray-600 text-sm md:text-base font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-gray-400 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-gray-400 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;