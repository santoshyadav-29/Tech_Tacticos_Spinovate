'use client';

import React, { useState } from 'react';
import { Calendar, User, ArrowRight, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

const News = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = ['All', 'Research', 'Partnerships', 'Awards', 'Events'];

  const newsItems = [
    {
      title: 'Green Hydrogen Lab Receives $10M DOE Grant for Advanced Electrolysis Research',
      category: 'Research',
      date: '2024-01-15',
      author: 'Dr. Sarah Chen',
      image: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=600',
      excerpt: 'Major funding will accelerate development of next-generation proton exchange membrane electrolyzers with unprecedented efficiency rates.',
      featured: true
    },
    {
      title: 'Partnership Announcement: Collaboration with Toyota on Fuel Cell Technology',
      category: 'Partnerships',
      date: '2024-01-10',
      author: 'Prof. Michael Rodriguez',
      image: 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg?auto=compress&cs=tinysrgb&w=600',
      excerpt: 'Strategic alliance to develop advanced fuel cell systems for next-generation hydrogen vehicles.'
    },
    {
      title: 'Dr. Chen Wins Prestigious Clean Energy Innovation Award',
      category: 'Awards',
      date: '2024-01-05',
      author: 'Communications Team',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=600',
      excerpt: 'Recognition for groundbreaking work in low-cost electrocatalyst development.'
    },
    {
      title: 'Upcoming: International Hydrogen Symposium 2024',
      category: 'Events',
      date: '2024-01-01',
      author: 'Events Team',
      image: 'https://images.pexels.com/photos/2280571/pexels-photo-2280571.jpeg?auto=compress&cs=tinysrgb&w=600',
      excerpt: 'Join us for three days of cutting-edge presentations and networking opportunities in San Francisco.'
    },
    {
      title: 'Breakthrough in Solid-State Hydrogen Storage Published in Nature',
      category: 'Research',
      date: '2023-12-20',
      author: 'Dr. James Wilson',
      image: 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg?auto=compress&cs=tinysrgb&w=600',
      excerpt: 'Novel metal hydride materials achieve record-breaking storage density and safety performance.'
    },
    {
      title: 'Lab Opens New 50MW Testing Facility',
      category: 'Research',
      date: '2023-12-15',
      author: 'Facilities Team',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=600',
      excerpt: 'State-of-the-art facility enables large-scale testing of industrial hydrogen production systems.'
    }
  ];

  const filteredNews = newsItems.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const featuredNews = filteredNews.filter(item => item.featured);
  const regularNews = filteredNews.filter(item => !item.featured);

  return (
    <section id="news" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16 scroll-reveal">
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk mb-6 bg-gradient-to-r from-gray-900 to-blue-800 bg-clip-text text-transparent">
            News & Events
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Stay updated with our latest research breakthroughs, partnerships, and industry developments.
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-12 scroll-reveal">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search news and events..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={activeCategory === category ? "default" : "outline"}
                onClick={() => setActiveCategory(category)}
                className={`${
                  activeCategory === category 
                    ? 'bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700' 
                    : 'hover:border-primary hover:text-primary'
                } transition-all duration-200`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Featured News */}
        {featuredNews.length > 0 && (
          <div className="mb-16">
            <h3 className="text-2xl font-bold font-space-grotesk mb-8 scroll-reveal">Featured</h3>
            {featuredNews.map((item, index) => (
              <Card key={index} className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 mb-8 overflow-hidden scroll-reveal">
                <div className="md:flex">
                  <div className="md:w-1/2 relative">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-64 md:h-full object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-red-500 text-white">Featured</Badge>
                    </div>
                  </div>
                  <div className="md:w-1/2 p-8">
                    <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(item.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center">
                        <User className="w-4 h-4 mr-1" />
                        {item.author}
                      </div>
                      <Badge variant="outline">{item.category}</Badge>
                    </div>
                    <h3 className="text-2xl font-bold font-space-grotesk mb-4 hover:text-primary transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed mb-6">{item.excerpt}</p>
                    <Button variant="outline" className="group hover:border-primary hover:text-primary">
                      Read More
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Regular News Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {regularNews.map((item, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group scroll-reveal">
              <div className="relative overflow-hidden rounded-t-lg">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4">
                  <Badge variant="secondary">{item.category}</Badge>
                </div>
              </div>
              <CardHeader>
                <div className="flex items-center gap-4 mb-2 text-sm text-gray-500">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    {new Date(item.date).toLocaleDateString()}
                  </div>
                  <div className="flex items-center">
                    <User className="w-4 h-4 mr-1" />
                    {item.author}
                  </div>
                </div>
                <CardTitle className="text-lg font-space-grotesk group-hover:text-primary transition-colors leading-tight">
                  {item.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">{item.excerpt}</p>
                <Button variant="ghost" className="p-0 h-auto text-blue-600 hover:text-blue-700 group">
                  Read More
                  <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More Button */}
        <div className="text-center mt-12 scroll-reveal">
          <Button size="lg" variant="outline" className="px-8 py-3 hover:border-primary hover:text-primary">
            Load More Articles
          </Button>
        </div>
      </div>
    </section>
  );
};

export default News;