'use client';

import React from 'react';
import { Users, Target, Lightbulb, Globe } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const About = () => {
  const values = [
    {
      icon: <Target className="w-8 h-8" />,
      title: 'Mission-Driven',
      description: 'Advancing sustainable energy solutions through innovative green hydrogen research and development.'
    },
    {
      icon: <Lightbulb className="w-8 h-8" />,
      title: 'Innovation First',
      description: 'Pushing the boundaries of hydrogen technology with cutting-edge research and breakthrough discoveries.'
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: 'Global Impact',
      description: 'Creating solutions that address climate challenges and accelerate the global energy transition.'
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Collaborative',
      description: 'Building partnerships across academia, industry, and policy to drive meaningful change.'
    }
  ];

  const team = [
    {
      name: 'Dr. Sarah Chen',
      role: 'Director & Lead Researcher',
      image: 'https://images.pexels.com/photos/3831645/pexels-photo-3831645.jpeg?auto=compress&cs=tinysrgb&w=400',
      bio: 'Leading expert in electrocatalysis with 15+ years in hydrogen technology research.'
    },
    {
      name: 'Prof. Michael Rodriguez',
      role: 'Head of Engineering',
      image: 'https://images.pexels.com/photos/3831645/pexels-photo-3831645.jpeg?auto=compress&cs=tinysrgb&w=400',
      bio: 'Specializes in fuel cell systems and hydrogen storage solutions.'
    },
    {
      name: 'Dr. Priya Patel',
      role: 'Policy & Strategy Lead',
      image: 'https://images.pexels.com/photos/3831645/pexels-photo-3831645.jpeg?auto=compress&cs=tinysrgb&w=400',
      bio: 'Expert in energy policy and sustainable technology implementation.'
    },
    {
      name: 'Dr. James Wilson',
      role: 'Materials Science Lead',
      image: 'https://images.pexels.com/photos/3831645/pexels-photo-3831645.jpeg?auto=compress&cs=tinysrgb&w=400',
      bio: 'Pioneer in advanced materials for hydrogen production and storage.'
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16 scroll-reveal">
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk mb-6 bg-gradient-to-r from-gray-900 to-blue-800 bg-clip-text text-transparent">
            About Our Lab
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Established in 2018, the Green Hydrogen Lab is at the forefront of sustainable energy research, 
            driving innovation in hydrogen technology to create a cleaner, more sustainable future.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-12 mb-20">
          <div className="scroll-reveal">
            <Card className="h-full border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold font-space-grotesk mb-4 text-green-700">Our Mission</h3>
                <p className="text-gray-600 leading-relaxed text-lg">
                  To accelerate the global transition to clean energy by developing breakthrough technologies 
                  in green hydrogen production, storage, and utilization. We bridge the gap between 
                  fundamental research and practical applications.
                </p>
              </CardContent>
            </Card>
          </div>
          <div className="scroll-reveal">
            <Card className="h-full border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold font-space-grotesk mb-4 text-blue-700">Our Vision</h3>
                <p className="text-gray-600 leading-relaxed text-lg">
                  A world powered by clean, sustainable hydrogen energy where research, innovation, 
                  and collaboration drive solutions to the climate crisis and create opportunities 
                  for a carbon-neutral economy.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Core Values */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold font-space-grotesk text-center mb-12 scroll-reveal">Our Core Values</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center scroll-reveal group">
                <div className="w-16 h-16 bg-gradient-to-br from-green-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <div className="text-green-600">{value.icon}</div>
                </div>
                <h4 className="text-xl font-semibold mb-3 font-space-grotesk">{value.title}</h4>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Team */}
        <div>
          <h3 className="text-3xl font-bold font-space-grotesk text-center mb-12 scroll-reveal">Leadership Team</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div key={index} className="text-center scroll-reveal group">
                <div className="relative mb-6 overflow-hidden rounded-xl">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <h4 className="text-xl font-bold font-space-grotesk mb-2">{member.name}</h4>
                <p className="text-green-600 font-semibold mb-3">{member.role}</p>
                <p className="text-gray-600 text-sm leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;