'use client';

import React, { useState } from 'react';
import { Download, FileText, Video, Database, BookOpen, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const Resources = () => {
  const [activeType, setActiveType] = useState('All');

  const resourceTypes = ['All', 'Whitepapers', 'Reports', 'Datasets', 'Tools', 'Videos'];

  const resources = [
    {
      title: 'Green Hydrogen Production: Technical and Economic Analysis',
      type: 'Whitepapers',
      format: 'PDF',
      size: '2.4 MB',
      icon: <FileText className="w-6 h-6" />,
      description: 'Comprehensive analysis of current green hydrogen production technologies and their economic viability.',
      downloads: 1250,
      date: '2024-01-15',
      featured: true
    },
    {
      title: 'Hydrogen Storage Solutions Database',
      type: 'Datasets',
      format: 'CSV',
      size: '15.2 MB',
      icon: <Database className="w-6 h-6" />,
      description: 'Complete dataset of hydrogen storage technologies, materials, and performance metrics.',
      downloads: 890,
      date: '2024-01-10'
    },
    {
      title: 'Annual Hydrogen Technology Report 2023',
      type: 'Reports',
      format: 'PDF',
      size: '8.7 MB',
      icon: <BookOpen className="w-6 h-6" />,
      description: 'Comprehensive overview of hydrogen technology developments, market trends, and future outlook.',
      downloads: 2100,
      date: '2023-12-20'
    },
    {
      title: 'Electrolysis Efficiency Calculator',
      type: 'Tools',
      format: 'Web Tool',
      size: 'Online',
      icon: <ExternalLink className="w-6 h-6" />,
      description: 'Interactive tool for calculating electrolysis system efficiency and cost optimization.',
      downloads: 750,
      date: '2024-01-05'
    },
    {
      title: 'Fuel Cell Technology Webinar Series',
      type: 'Videos',
      format: 'MP4',
      size: '1.2 GB',
      icon: <Video className="w-6 h-6" />,
      description: 'Educational video series covering advanced fuel cell technologies and applications.',
      downloads: 650,
      date: '2023-12-15'
    },
    {
      title: 'Hydrogen Safety Guidelines',
      type: 'Whitepapers',
      format: 'PDF',
      size: '1.8 MB',
      icon: <FileText className="w-6 h-6" />,
      description: 'Essential safety protocols and best practices for hydrogen handling and storage.',
      downloads: 1800,
      date: '2023-12-10'
    },
    {
      title: 'Materials Science Research Data',
      type: 'Datasets',
      format: 'JSON',
      size: '25.5 MB',
      icon: <Database className="w-6 h-6" />,
      description: 'Raw research data from materials science experiments and catalyst development.',
      downloads: 420,
      date: '2023-12-05'
    },
    {
      title: 'Policy Framework for Hydrogen Economy',
      type: 'Reports',
      format: 'PDF',
      size: '5.1 MB',
      icon: <BookOpen className="w-6 h-6" />,
      description: 'Policy recommendations and regulatory framework for hydrogen economy development.',
      downloads: 980,
      date: '2023-11-25'
    }
  ];

  const filteredResources = activeType === 'All' 
    ? resources 
    : resources.filter(resource => resource.type === activeType);

  const featuredResources = filteredResources.filter(resource => resource.featured);
  const regularResources = filteredResources.filter(resource => !resource.featured);

  return (
    <section id="resources" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16 scroll-reveal">
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk mb-6 bg-gradient-to-r from-gray-900 to-blue-800 bg-clip-text text-transparent">
            Resources & Tools
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Access our comprehensive library of research publications, datasets, tools, and educational materials.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-2 mb-12 scroll-reveal">
          {resourceTypes.map((type) => (
            <Button
              key={type}
              variant={activeType === type ? "default" : "outline"}
              onClick={() => setActiveType(type)}
              className={`${
                activeType === type 
                  ? 'bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700' 
                  : 'hover:border-primary hover:text-primary'
              } transition-all duration-200`}
            >
              {type}
            </Button>
          ))}
        </div>

        {/* Featured Resources */}
        {featuredResources.length > 0 && (
          <div className="mb-16">
            <h3 className="text-2xl font-bold font-space-grotesk mb-8 scroll-reveal">Featured Resources</h3>
            {featuredResources.map((resource, index) => (
              <Card key={index} className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 mb-8 overflow-hidden scroll-reveal">
                <div className="md:flex">
                  <div className="md:w-1/4 bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-8">
                    <div className="text-6xl text-green-600 opacity-80">
                      {resource.icon}
                    </div>
                  </div>
                  <div className="md:w-3/4 p-8">
                    <div className="flex items-center gap-4 mb-4">
                      <Badge className="bg-red-500 text-white">Featured</Badge>
                      <Badge variant="outline">{resource.type}</Badge>
                      <span className="text-sm text-gray-500">{resource.date}</span>
                    </div>
                    <h3 className="text-2xl font-bold font-space-grotesk mb-4 hover:text-primary transition-colors">
                      {resource.title}
                    </h3>
                    <p className="text-gray-600 leading-relaxed mb-6">{resource.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-6 text-sm text-gray-500">
                        <span>Format: {resource.format}</span>
                        <span>Size: {resource.size}</span>
                        <span>{resource.downloads} downloads</span>
                      </div>
                      <Button className="bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Regular Resources Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {regularResources.map((resource, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 group scroll-reveal">
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-100 to-blue-100 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <div className="text-green-600">{resource.icon}</div>
                  </div>
                  <Badge variant="outline">{resource.type}</Badge>
                </div>
                <CardTitle className="text-lg font-space-grotesk group-hover:text-primary transition-colors leading-tight">
                  {resource.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">{resource.description}</p>
                
                <div className="space-y-2 text-xs text-gray-500 mb-4">
                  <div className="flex justify-between">
                    <span>Format:</span>
                    <span>{resource.format}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Size:</span>
                    <span>{resource.size}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Downloads:</span>
                    <span>{resource.downloads}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Date:</span>
                    <span>{resource.date}</span>
                  </div>
                </div>

                <Button variant="outline" className="w-full group-hover:border-primary group-hover:text-primary">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Resource Categories Overview */}
        <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-8 scroll-reveal">
          <h3 className="text-2xl font-bold font-space-grotesk text-center mb-8">Resource Categories</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: <FileText className="w-8 h-8" />, title: 'Whitepapers', count: '25+', description: 'Technical papers and research findings' },
              { icon: <BookOpen className="w-8 h-8" />, title: 'Reports', count: '15+', description: 'Annual reports and market analysis' },
              { icon: <Database className="w-8 h-8" />, title: 'Datasets', count: '40+', description: 'Research data and benchmarks' },
              { icon: <Video className="w-8 h-8" />, title: 'Videos', count: '30+', description: 'Educational content and webinars' }
            ].map((category, index) => (
              <div key={index} className="text-center group">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300">
                  <div className="text-green-600">{category.icon}</div>
                </div>
                <h4 className="text-lg font-semibold mb-2 font-space-grotesk">{category.title}</h4>
                <div className="text-2xl font-bold text-blue-600 mb-2">{category.count}</div>
                <p className="text-gray-600 text-sm">{category.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Resources;